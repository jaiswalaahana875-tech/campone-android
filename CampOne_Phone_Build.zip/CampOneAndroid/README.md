# CampOne — Native Android App

This is the Android Studio project for CampOne. It wraps the real CampOne college companion in a native Android shell with:

- CampOne logo as launcher icon and splash screen
- Native Android back navigation
- Native file picker for profile pictures/notes
- Native Android notifications with permission handling
- Portrait phone layout
- Local app storage from the existing CampOne web UI
- UPES portal links opening outside the app when appropriate
- The existing CampOne themes and college companion features

## Build

Open this folder in Android Studio (latest stable), let Gradle sync, then choose **Build → Build APK(s)**.

For a release APK, use **Build → Generate Signed App Bundle / APK** and create/use your own signing key.

## Important security notes

Do not put an OpenAI API key or your UPES password inside the APK. The CampOne AI should call a secure backend that keeps the OpenAI key server-side. UPES authentication should use an official API/SSO/OAuth integration if available; CampOne should not store raw portal passwords.

The current project includes the Android-side notification bridge. The existing CampOne HTML remains responsible for the dashboard, themes, profile picture options, tasks, timetable, notes, portal UI, and AI interface.
