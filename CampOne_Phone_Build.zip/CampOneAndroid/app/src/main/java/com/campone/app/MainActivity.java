package com.campone.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    WebView web;
    private static final int NOTIFY_REQ = 701;
    private ValueCallback<Uri[]> uploadCallback;
    private static final int FILE_REQ = 702;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(13,13,13));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(13,13,13));
        showSplashThenApp();
    }

    private void showSplashThenApp() {
        ImageView splash = new ImageView(this);
        splash.setBackgroundColor(android.graphics.Color.rgb(13,13,13));
        splash.setImageResource(R.drawable.campone_splash);
        splash.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        setContentView(splash);
        new Handler(Looper.getMainLooper()).postDelayed(this::loadApp, 1200);
    }

    private void loadApp() {
        web = new WebView(this);
        web.setBackgroundColor(android.graphics.Color.rgb(248,244,238));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (u.getScheme() != null && !u.getScheme().equals("file")) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch(Exception ignored) {}
                    return true;
                }
                return false;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams params) {
                uploadCallback = cb;
                try {
                    Intent i = params.createIntent();
                    startActivityForResult(i, FILE_REQ);
                    return true;
                } catch(Exception e) { uploadCallback = null; return false; }
            }
        });
        web.addJavascriptInterface(new NativeBridge(this), "CampOneNative");
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
    }

    public void requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFY_REQ);
        } else {
            Toast.makeText(this, "CampOne notifications are enabled.", Toast.LENGTH_SHORT).show();
        }
    }

    public void scheduleNotification(String title, String body, long delayMs) {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFY_REQ);
            return;
        }
        Intent i = new Intent(this, NotificationReceiver.class).putExtra("title", title).putExtra("body", body);
        PendingIntent pi = PendingIntent.getBroadcast(this, (int)(System.currentTimeMillis() & 0x7fffffff), i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am = (AlarmManager)getSystemService(ALARM_SERVICE);
        long when = System.currentTimeMillis() + Math.max(1000, delayMs);
        if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi); else am.set(AlarmManager.RTC_WAKEUP, when, pi);
        Toast.makeText(this, "Notification scheduled in " + Math.max(1, delayMs/60000) + " min.", Toast.LENGTH_SHORT).show();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_REQ && uploadCallback != null) {
            Uri[] results = (resultCode == RESULT_OK && data != null) ? new Uri[]{data.getData()} : null;
            uploadCallback.onReceiveValue(results);
            uploadCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
