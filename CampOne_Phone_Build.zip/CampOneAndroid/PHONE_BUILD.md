# Build CampOne APK using only your phone

1. Open github.com in Chrome and sign in (or create a GitHub account).
2. Create a new repository, e.g. `campone-android`.
3. Open the repository and choose **Add file → Upload files**.
4. Upload the **contents** of this `CampOneAndroid` folder (including `.github`, `app`, `gradle`, `build.gradle`, and `settings.gradle`). If GitHub's mobile uploader hides `.github`, create the workflow file manually at `.github/workflows/build-apk.yml` using the file in this package.
5. Commit the files.
6. Open the repository's **Actions** tab.
7. Select **Build CampOne APK**.
8. Tap **Run workflow** → **Run workflow**.
9. Wait for the green checkmark.
10. Open that workflow run and scroll to **Artifacts**.
11. Download **CampOne-debug-apk.zip**.
12. Extract it on your phone and tap `app-debug.apk` to install.

The APK is a debug build for personal testing. Do not put your OpenAI API key or UPES password into the APK source. Keep secrets on a secure backend.
