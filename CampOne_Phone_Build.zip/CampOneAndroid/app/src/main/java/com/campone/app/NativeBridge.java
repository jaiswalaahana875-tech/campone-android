package com.campone.app;

import android.webkit.JavascriptInterface;

public class NativeBridge {
    private final MainActivity activity;
    public NativeBridge(MainActivity a) { activity = a; }
    @JavascriptInterface public void requestNotifications() { activity.runOnUiThread(activity::requestNotifications); }
    @JavascriptInterface public void scheduleNotification(String title, String body, long delayMs) { activity.runOnUiThread(() -> activity.scheduleNotification(title, body, delayMs)); }
}
